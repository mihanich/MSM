self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "210cdfec75f8819cf88af6d7c1143fa7",
    "url": "/index.html"
  },
  {
    "revision": "bef5f9e0837401d4a7df",
    "url": "/static/css/2.c38cd9da.chunk.css"
  },
  {
    "revision": "bef5f9e0837401d4a7df",
    "url": "/static/js/2.ef060f46.chunk.js"
  },
  {
    "revision": "28ce00ad444b69bea42850e06eec9da3",
    "url": "/static/js/2.ef060f46.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c0cd579ca18a0480cc24",
    "url": "/static/js/main.2b22a9e9.chunk.js"
  },
  {
    "revision": "0e903404fe668039b1a7",
    "url": "/static/js/runtime-main.2a78626f.js"
  },
  {
    "revision": "34c0c94e712ddb861346d68dfb00ab87",
    "url": "/static/media/logo.34c0c94e.svg"
  }
]);